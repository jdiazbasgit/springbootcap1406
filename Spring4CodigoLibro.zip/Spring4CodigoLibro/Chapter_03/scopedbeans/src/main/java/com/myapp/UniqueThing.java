package com.myapp;

import org.springframework.stereotype.Component;

@Component
public class UniqueThing {
  // the details of this class are inconsequential to this example
}
