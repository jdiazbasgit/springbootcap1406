package spittr;

public interface SpittleFeedService {

	void broadcastSpittle(Spittle spittle);

}