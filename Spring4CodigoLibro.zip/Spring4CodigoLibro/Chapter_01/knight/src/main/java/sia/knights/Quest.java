package sia.knights;

public interface Quest {

  void embark();

}
