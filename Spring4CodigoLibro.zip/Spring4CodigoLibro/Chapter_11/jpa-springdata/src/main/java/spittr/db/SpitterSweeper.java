package spittr.db;

public interface SpitterSweeper {

	int eliteSweep();

}
